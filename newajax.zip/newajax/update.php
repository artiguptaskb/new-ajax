<?php
include "config.php";

$id=$_POST['id'];
$name=$_POST['name'];
$course=$_POST['course'];
$sql="UPDATE `user` SET `id`='$id',`name`='$name',`course`='$course' WHERE `id`='$id'";
mysqli_query($con,$sql);
// echo "successfull";

?>