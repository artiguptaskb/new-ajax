<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<?php

include "config.php";
$sdata=$_POST['name'];
$sql="SELECT * FROM `user` WHERE `name` LIKE '%$sdata%' or `course` LIKE '%$sdata%'";
$result=mysqli_query($con,$sql);
$output="";
  $output.="<table class='table'>";
  
  $output.='<tr>
  <th>id</th>
  <th>name</th>
  <th>password</th>
  <th>DELETE</th>
  <th>UPDATE</th>
  </tr>';
 

while($value=mysqli_fetch_array($result)){
  
$output.="<tr>

<td>{$value["id"]}</td>
<td>{$value["name"]}</td>
<td>{$value["course"]}</td>
<td><a class='btn btn-danger di' data-id='{$value['id']}';>Delete</a></td>
<td><a class='btn btn-warning du' data-id='{$value['id']}'>Edit</a></td>

<tr>";



}


$output.='</table>';



echo $output;


?>