<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>

</head>
<body>
   <h1>SELECT STATE</h1> 
    <select name="" id="ct">
        <option selected disabled> SELECT YOUR CT </option>
    </select>

    <select name="" id="st">
    </select>

    <select name="" id="dist">
    </select>


<script>
    $.ajax({
        url:"country_load.php",
        success:function(data){
            $("#ct").append(data);
        }
    })
    $("#ct").on("change",function(){
        var city=$(this).val();
        $.ajax({
        url:"state_load.php",
        type:"POST",
        data:{id:city},
        success:function(data){
            $("#st").html(data);
        }
    }) 
    })

    $("#st").on("change",function(){
        var state=$(this).val();
        $.ajax({
        url:"dist_load.php",
        type:"POST",
        data:{id:state},
        success:function(data){
            $("#dist").html(data);
        }
    }) 
    })

</script>
    
</body>
</html>