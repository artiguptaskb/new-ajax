<?php


include "config.php";

$name=$_POST['$stname'];
$course=$_POST['$stcourse'];
$sql="INSERT INTO `user`(`id`,`name`,`course`) VALUES (NULL,'$name','$course')";
mysqli_query($con,$sql);
// echo "successfulluy";








?>