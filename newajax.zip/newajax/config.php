<?php
$con=mysqli_connect("localhost","root","","newajax") or die();
?>