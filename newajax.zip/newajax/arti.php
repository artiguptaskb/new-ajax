<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
</head>
<style>
    .uform{
        position: absolute;
        background-color: red;
        /* padding: 40px; */
        left: 35%;
        top: 200px;
        transform: translateY(-180px);
        transition-duration: 1s;
        transition-delay: 1s;
        animation-name: example;
        animation-duration: 5s;
    }
    @keyframes example {
  0%   { top:400px;}
  25%  {top:0px;}
  50%  {top:200px;}
}
   
    h1{
        color: white;
    }
     form input{
        margin: 10px;
    }
    .formnone{
        top: -400px;
    }
    .on{
        display: none;
    }
</style>
<body>

<div class="alert alert-warning alert-dismissible on" role="alert">
  <strong>Holy guacamole!</strong> You should check in on some of those fields below.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true" id="show" data-bs-dismiss="alert" >&times;</span>
  </button>
</div>



    


<!-- <button id="show">click here</button>  -->


<form class="enform">
    <input type="text" id="name" placeholder="enter user name"> 
    <input type="text" id="course" placeholder="enter user name"> <br> <br>
    <input type="submit" id="submit">
</form>

<input type="text"  placeholder="Search here" class="form-control" id="search"> 
 <button class="btn btn-danger" id="filter">seach</button> 


<div class="show">
</div>

<div id="notfound">

</div>

 <div class="uform formnone">
</div>

<script>

$(document).ready(function(){
    $("#search").on("keyup",function(){
        var sdata=$(this).val();
        $.ajax({
            url:"filter.php",
            type:"POST",
            data:{name:sdata},
            success:function(data){
                $(".show").html(data);
                var a=$(".show tr").length
                if(a<2){
                    $("#notfound").text("record not found");
                }
                else{
                    $("#notfound").text("");
                }
            }
        })
    })
})

$("#submit").on("click",function(e){
    e.preventDefault();
    var name=$("#name").val();
    var course=$("#course").val();
    $.ajax({
       url:"insert.php",
       type:"POST",
       data:{name:name,course:course},
       success:function(data){
        if(data=="true"){
            $(".alert").removeClass("on");
            abc();
            $(".enform").trigger("reset");
            alert ("data has been insert successfully");
        }
        else{
            alert ("data not has been insert");
        }
    }
       

    })
})

$(document).on("click",".du",function(){
    var id=$(this).data("id");
    $.ajax({
        url:"edit.php",
        type:"POST",
        data:{id:id},
        success:function(data){
        $(".uform").html(data)
        $(".uform").removeClass("formnone")


        }
    })
})
$(document).on("click",".next", function(){
    var sn=$(this).data('id');
    $.ajax({
        url:"select.php",
        type:"POST",
        data:{sn:sn},
        success:function(data){
            $(".show").html(data);
        }

    })
})
$(document).on("click","#update",function(e){
    e.preventDefault();
    var id = $(".id").val();
    var name = $(".name").val();
    var course = $(".course").val();
    $.ajax({
        url:"update.php",
        type:"POST",
        data:{id:id,name:name,course:course},
        success:function(data){
            $(".uform").addClass("formnone");
            abc();
            alert("data has been update");
        }
    })
  
    
})

$(document).on("click","#usubmit",function(e){
    e.preventDefault();
    var name=$(".name").val();
    alert(name);
})

$(document).on("click",".di",function(){
    if (confirm('Are you sure you want to delete this item?')) {
    var id=$(this).data("id");
    $.ajax({
        url:"delete.php",
        type:"POST",
        data:{id:id},
        success:function(data){
            abc();


        }
    
    })
}
    
})


function abc(){
$.ajax({
    url:"select.php",
    type:"POST",
    success:function(arti){
        $(".show").html(arti);

    }
})
}

abc();





 
   



</script>
</body>
</html>