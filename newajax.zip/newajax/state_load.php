<?php
include "config.php";
$id=$_POST['id'];
$sql="SELECT  * FROM `state` WHERE `cid`=$id";
$result=mysqli_query($con,$sql);
$output="";
while($value=mysqli_fetch_array($result)){
    $output.="<option value='{$value['sid']}'>{$value['sname']}</option>";
}
echo $output;
?>