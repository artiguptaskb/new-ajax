<?php

include "config.php";

$name=$_POST['name'];
$course=$_POST['course'];


$sql="INSERT INTO `user`(`id`,`name`,`course`) VALUES (NULL,'$name','$course')";


if(mysqli_query($con,$sql)){
    echo "true";
}
else{
    echo "false";
}

?>
