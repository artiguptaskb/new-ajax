<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<?php

include "config.php";
if(isset($_POST['sn'])){
$sn=$_POST['sn'];
$sn++;
$end=$sn+4;
}
else{
    $sn=92;
    $end=147;
}

$sql="SELECT * FROM `user` WHERE `id` BETWEEN $sn AND $end";
$result=mysqli_query($con,$sql);
$output="";
$output.="<table class='table'>";
  
  $output.='<tr>
  <th>id</th>
  <th>name</th>
  <th>password</th>
  <th>DELETE</th>
  <th>UPDATE</th>
  </tr>';

  $id=0;
 

while($value=mysqli_fetch_array($result)){
  $id++;
  
$output.="<tr>

<td>{$id}</td>
<td>{$value["name"]}</td>
<td>{$value["course"]}</td>
<td><a class='btn btn-danger di' data-id='{$value['id']}';>Delete</a></td>
<td><a class='btn btn-warning du' data-id='{$value['id']}'>Edit</a></td>

<tr>";



}


$output.='</table>';


$output.="<input class='btn form-control btn-primary next' data-id='{$end}' value='Next'>";



echo $output;


?>