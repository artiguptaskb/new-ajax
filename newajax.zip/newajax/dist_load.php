<?php
include "config.php";
$id=$_POST['id'];
$sql="SELECT  * FROM `dist` WHERE `sid`=$id";
$result=mysqli_query($con,$sql);
$output="";
while($value=mysqli_fetch_array($result)){
    $output.="<option value='{$value['did']}'>{$value['dname']}</option>";
}
echo $output;
?>