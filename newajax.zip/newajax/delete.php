<?php
include "config.php";
$id=$_POST['id'];
$sql="DELETE FROM `user` WHERE `id`='$id'";
mysqli_query($con,$sql);


//  echo "<script> var confirmation = confirm('are you sure you want to remove the item?');</script>";
?>