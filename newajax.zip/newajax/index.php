<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<style>
    .dis{
        transform: translateX(-400px);
       
    }
    .alert{
        /* width: 300px; */
        transition: all;
        transition-property: all;
        transition-duration: 2s;
        
    }
</style>
<body>
    





 <!-- <button class="click">click here</button>
<div class="show"></div>  -->

<div class="alert alert-warning alert-dismissible fade show " role="alert">
  <strong>Holy guacamole!</strong> You should check in on some of those fields below.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true" id="show">&times;</span>
  </button>
</div>

<!-- <div class="show"></div> -->

<form  method="post">
    <input type="text" id="name" placeholder="enter name">
    <select  id="course">
        <option   selected disabled  >degital marketing</option>
        <option value="web design">web design</option>
        <option value="Animation">Animation</option>
    </select>
    <button id="submit">submit</button>
</form>


<script>
 
    $("#submit").on("click",function(e){
        e.preventDefault();
        var name=$("#name").val();
        var course=$("#course").val();
        $.ajax({
            url:"query.php",
            type:"POST",
            data:{$stname:name,$stcourse:course},
            success:function(abc){
                $(".show").html(abc);
                $(".alert").removeClass("dis");
                xyz();
                var b=setInterval(abc,2000);
            }
        }) 

    })

    function abc(){
        time++;
        if(time>5){
            $(".alert").addClass("dis");
            clearInterval(b);
        }
    }

    

  
</script>
    
</body>
</html>